package com.imran.gamepadmapper

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MapperScreen { uri, mime -> openAccessibilitySettings(); } }
    }
    private fun openAccessibilitySettings() {
        startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }
}

@Composable
fun MapperScreen(onEnableService: (Uri?, String?) -> Unit) {
    var selectedMedia by remember { mutableStateOf<Uri?>(null) }
    var mediaType by remember { mutableStateOf("Belum ada media") }
    var showControls by remember { mutableStateOf(true) }
    var sensitivity by remember { mutableFloatStateOf(1f) }
    var buttonSize by remember { mutableFloatStateOf(58f) }
    var status by remember { mutableStateOf("Mode editor — belum berjalan di atas game") }
    val mediaPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            selectedMedia = uri
            mediaType = if (uri.toString().substringBefore("?").lowercase().let { it.endsWith(".mp4") || it.endsWith(".webm") || it.endsWith(".mov") }) "Video dipilih" else "Media dipilih"
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF35D7FF),
        background = Color(0xFF080B12),
        surface = Color(0xFF111827)
    )) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF080B12)) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("NEXPAD  •  GAMEPAD MAPPER", color = Color(0xFF35D7FF), fontSize = 20.sp)
                Text("Editor overlay & pemetaan tombol", color = Color.LightGray)
                Box(
                    Modifier.fillMaxWidth().weight(1f)
                        .border(1.dp, Color(0xFF35D7FF), RoundedCornerShape(18.dp))
                        .background(Color(0xFF101827), RoundedCornerShape(18.dp))
                ) {
                    Column(Modifier.align(Alignment.TopStart).padding(12.dp)) {
                        Text(mediaType, color = Color.White)
                        Text("Area pratinjau  •  ${if (selectedMedia == null) "kosong" else "media terpilih"}",
                            color = Color.Gray, fontSize = 12.sp)
                        Text("Pilih foto/video untuk referensi editor. Preview media penuh dapat dikembangkan berikutnya.",
                            color = Color.LightGray, fontSize = 11.sp)
                    }
                    if (showControls) {
                        DraggableButton("A", 0.16f, 0.70f)
                        DraggableButton("B", 0.28f, 0.60f)
                        DraggableButton("X", 0.76f, 0.64f)
                        DraggableButton("Y", 0.87f, 0.53f)
                        Text("D-pad", Modifier.align(Alignment.BottomStart).padding(18.dp)
                            .background(Color(0xCC172033), RoundedCornerShape(12.dp)).padding(12.dp),
                            color = Color.White)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { mediaPicker.launch(arrayOf("image/*", "video/*")) }) { Text("Pilih foto/video") }
                    OutlinedButton(onClick = { showControls = !showControls }) {
                        Text(if (showControls) "Sembunyikan tombol" else "Tampilkan tombol")
                    }
                }
                Text("Ukuran tombol: ${buttonSize.roundToInt()} dp", color = Color.White)
                Slider(value = buttonSize, onValueChange = { buttonSize = it }, valueRange = 36f..92f)
                Text("Sensitivitas editor: ${"%.1f".format(sensitivity)}×", color = Color.White)
                Slider(value = sensitivity, onValueChange = { sensitivity = it }, valueRange = 0.5f..2f)
                Text("Sensitivitas hanya preferensi UI; tidak mengubah statistik/damage game.", color = Color.Gray, fontSize = 12.sp)
                Button(onClick = { onEnableService(null, null); status = "Buka Accessibility lalu aktifkan Gamepad Mapper input service." },
                    modifier = Modifier.fillMaxWidth()) { Text("Buka pengaturan Accessibility") }
                Text(status, color = Color(0xFF35D7FF), fontSize = 12.sp)
                Text("Catatan: pemetaan input sintetis tidak didukung oleh semua game/perangkat.",
                    color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun DraggableButton(label: String, startX: Float, startY: Float) {
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    Box(
        Modifier.offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .padding(start = (startX * 260).dp, top = (startY * 220).dp)
            .size(54.dp)
            .background(Color(0xCC172A42), RoundedCornerShape(50))
            .border(1.dp, Color(0xFF35D7FF), RoundedCornerShape(50))
            .pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    offsetX += drag.x
                    offsetY += drag.y
                }
            },
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 18.sp) }
}

