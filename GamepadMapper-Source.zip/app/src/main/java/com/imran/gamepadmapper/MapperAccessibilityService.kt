package com.imran.gamepadmapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Contoh minimum: tombol gamepad A/B/X/Y memicu tap di titik layar.
 * Koordinat demo harus disesuaikan; service tidak mengubah data atau mekanisme internal game.
 */
class MapperAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0) return false
        val point = when (event.keyCode) {
            KeyEvent.KEYCODE_BUTTON_A -> 0.78f to 0.78f
            KeyEvent.KEYCODE_BUTTON_B -> 0.88f to 0.66f
            KeyEvent.KEYCODE_BUTTON_X -> 0.68f to 0.66f
            KeyEvent.KEYCODE_BUTTON_Y -> 0.78f to 0.54f
            else -> return false
        }
        val dm = resources.displayMetrics
        val path = Path().apply { moveTo(dm.widthPixels * point.first, dm.heightPixels * point.second) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 45))
            .build()
        dispatchGesture(gesture, null, null)
        return true
    }
}
